#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <pwd.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
#include <filesystem>
#include <sstream>
#include <iomanip>
#include <chrono>

namespace fs = std::filesystem;

struct Item { std::string name, path; bool dir=false; unsigned long long size=0; };
struct Ring { int depth; std::string path; std::string name; bool dir; double x,y,z,r; std::vector<Item> items; };

static const int TOP=64, BOTTOM=30;
static Display* dpy; static Window win; static GC gc; static int W=1280,H=820;
static std::string currentPath; static std::vector<Item> currentItems; static int selected=-1;
static double zoom=1.0, rotX=-0.25, rotY=0.55; static bool dragging=false; static int dragX,dragY; static bool needsRedraw=true;
static std::vector<Ring> rings;
static unsigned long bg=0, fg=0, muted=0, accent=0, dircol=0, filecol=0, panel=0;

static unsigned long rgb(unsigned r,unsigned g,unsigned b){ return (r<<16)|(g<<8)|b; }
static void rect(int x,int y,int w,int h,unsigned long c){ XSetForeground(dpy,gc,c); XFillRectangle(dpy,win,gc,x,y,w,h); }
static void line(int x1,int y1,int x2,int y2,unsigned long c){ XSetForeground(dpy,gc,c); XDrawLine(dpy,win,gc,x1,y1,x2,y2); }
static void circle(int x,int y,int r,unsigned long c,bool fill=true){ XSetForeground(dpy,gc,c); if(fill) XFillArc(dpy,win,gc,x-r,y-r,2*r,2*r,0,360*64); else XDrawArc(dpy,win,gc,x-r,y-r,2*r,2*r,0,360*64); }
static void text(int x,int y,const std::string&s,unsigned long c){ XSetForeground(dpy,gc,c); XDrawString(dpy,win,gc,x,y,s.c_str(),(int)s.size()); }
static std::string ell(const std::string&s,int n){ if((int)s.size()<=n)return s; return s.substr(0,std::max(0,n-3))+"..."; }

static bool isDir(const std::string&p){ struct stat st{}; return stat(p.c_str(),&st)==0 && S_ISDIR(st.st_mode); }
static std::vector<Item> scan(const std::string&p){
    std::vector<Item> out; DIR* d=opendir(p.c_str()); if(!d) return out; dirent* e;
    while((e=readdir(d))){ if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")) continue; std::string n=e->d_name; std::string q=p+"/"+n; bool dir=false; struct stat st{}; if(lstat(q.c_str(),&st)==0) dir=S_ISDIR(st.st_mode); out.push_back({n,q,dir,(unsigned long long)(S_ISREG(st.st_mode)?st.st_size:0)}); }
    closedir(d); std::sort(out.begin(),out.end(),[](const Item&a,const Item&b){ if(a.dir!=b.dir)return a.dir>b.dir; return a.name<b.name; }); return out;
}
static double calcRadius(size_t n){
    const double minSpacing=42.0, objectPadding=28.0, labelPadding=14.0, minR=95.0, maxR=290.0;
    if(n==0) return minR;
    double circumference=n*minSpacing;
    double r=circumference/(2*M_PI)+objectPadding+labelPadding;
    return std::min(maxR,std::max(minR,r));
}
static void loadCurrent(){ currentItems=scan(currentPath); selected= currentItems.empty()?-1:0; needsRedraw=true; }
static std::string parentPath(std::string p){ if(p=="/")return p; while(p.size()>1&&p.back()=='/')p.pop_back(); auto i=p.find_last_of('/'); return i==0?"/":p.substr(0,i); }
static void enterDir(const std::string&p){ if(isDir(p)){ currentPath=p; loadCurrent(); } }
static void launch(const std::string&p){ std::string cmd="xdg-open -- \""+p+"\" >/dev/null 2>&1 &"; std::system(cmd.c_str()); }

static void project(double x,double y,double z,int&sx,int&sy){
    double cy=cos(rotY),srot=sin(rotY),cx=cos(rotX),sxr=sin(rotX);
    double X=cy*x+srot*z; double Z=-srot*x+cy*z; double Y=cx*y-sxr*Z; Z=sxr*y+cx*Z;
    double persp=700.0/(700.0+Z);
    sx=(int)(W*0.57 + X*zoom*persp); sy=(int)(H*0.54 + Y*zoom*persp);
}
static void buildRings(){
    rings.clear();
    Ring root; root.depth=0; root.path=currentPath; root.name=fs::path(currentPath).filename().string(); if(root.name.empty())root.name=currentPath; root.dir=true; root.items=currentItems; root.x=0;root.y=0;root.z=0;root.r=calcRadius(root.items.size()); rings.push_back(root);
    // Expand a few directory children automatically, producing many independent rings without overwhelming the scene.
    int maxDepth=7; std::vector<int> frontier={0};
    for(int depth=1;depth<maxDepth;depth++){
        std::vector<int> next;
        for(int ri:frontier){ auto &pr=rings[ri]; int count=0; for(size_t i=0;i<pr.items.size() && count<4;i++) if(pr.items[i].dir){
            const auto &it=pr.items[i]; Ring r; r.depth=depth; r.path=it.path; r.name=it.name; r.dir=true; r.items=scan(it.path); r.r=calcRadius(r.items.size());
            double a=(double)i/std::max<size_t>(1,pr.items.size())*2*M_PI + depth*0.8;
            double spread=pr.r*1.25+65; r.x=pr.x+cos(a)*spread; r.y=pr.y+sin(a)*spread*0.72; r.z=pr.z+(depth%2?55:-45); rings.push_back(r); next.push_back((int)rings.size()-1); count++; }
        }
        frontier=next; if(frontier.empty())break;
    }
}

static void drawRing(const Ring&r){
    int cx,cy; project(r.x,r.y,r.z,cx,cy); int rr=(int)(r.r*zoom*0.9);
    circle(cx,cy,rr,muted,false);
    text(cx-ell(r.name,22).size()*3,cy-rr-10,ell(r.name,22),fg);
    if(r.items.empty()){ circle(cx,cy,7,accent); return; }
    for(size_t i=0;i<r.items.size();i++){
        if(i>80)break; // initial virtualization safety
        double a=2*M_PI*(double)i/(double)r.items.size()-M_PI/2;
        double px=r.x+cos(a)*r.r, py=r.y+sin(a)*r.r, pz=r.z;
        int x,y; project(px,py,pz,x,y);
        bool dir=r.items[i].dir; circle(x,y,dir?8:6,dir?dircol:filecol);
        std::string label=ell(r.items[i].name,18);
        int tw=(int)label.size()*6;
        text(x-tw/2,y+(dir?22:19),label,dir?fg:muted);
    }
    circle(cx,cy,5,accent);
}
static void draw(){
    rect(0,0,W,H,bg); rect(0,0,W,TOP,panel); rect(0,H-BOTTOM,W,BOTTOM,panel);
    text(20,24,"CONSTELLATION FILE MANAGER",accent); text(20,47,ell(currentPath,80),fg);
    text(W-270,24,"Wheel: zoom   Drag: orbit",muted); text(W-270,47,"Enter: open   Backspace: parent",muted);
    // connectors first
    for(size_t i=1;i<rings.size();i++){ int x1,y1,x2,y2; project(rings[i].x,rings[i].y,rings[i].z,x1,y1); project(rings[i-1].x,rings[i-1].y,rings[i-1].z,x2,y2); line(x1,y1,x2,y2,muted); }
    for(auto &r:rings) drawRing(r);
    // selected current directory item highlight in top/root ring
    if(selected>=0 && selected<(int)currentItems.size()){
        auto &r=rings[0]; double a=2*M_PI*(double)selected/(double)r.items.size()-M_PI/2; int x,y; project(r.x+cos(a)*r.r,r.y+sin(a)*r.r,r.z,x,y); circle(x,y,14,accent,false);
    }
    std::ostringstream ss; ss<<currentItems.size()<<" items   |   "; if(selected>=0)ss<<"Selected: "<<ell(currentItems[selected].name,42); else ss<<"Nothing selected"; text(20,H-10,ss.str(),fg);
    XFlush(dpy);
}

static int hitCurrent(int mx,int my){
    if(currentItems.empty())return -1; Ring&r=rings[0]; double best=22; int bi=-1;
    for(size_t i=0;i<r.items.size()&&i<81;i++){ double a=2*M_PI*(double)i/(double)r.items.size()-M_PI/2; int x,y; project(r.x+cos(a)*r.r,r.y+sin(a)*r.r,r.z,x,y); double d=hypot(mx-x,my-y); if(d<best){best=d;bi=(int)i;} } return bi;
}

int main(){
    const char* home=getenv("HOME"); currentPath=home?home:"/";
    dpy=XOpenDisplay(nullptr); if(!dpy){fprintf(stderr,"Cannot open X display.\n");return 1;} int scr=DefaultScreen(dpy);
    bg=rgb(10,10,16); fg=rgb(225,220,232); muted=rgb(100,100,120); accent=rgb(220,105,150); dircol=rgb(235,150,90); filecol=rgb(120,155,220); panel=rgb(18,18,28);
    win=XCreateSimpleWindow(dpy,RootWindow(dpy,scr),0,0,W,H,0,bg,bg); XStoreName(dpy,win,"Filesystem Constellation — Native Linux File Manager");
    XSelectInput(dpy,win,ExposureMask|KeyPressMask|ButtonPressMask|ButtonReleaseMask|PointerMotionMask|StructureNotifyMask); XMapWindow(dpy,win); gc=XCreateGC(dpy,win,0,nullptr);
    loadCurrent(); buildRings();
    while(true){ XEvent e; XNextEvent(dpy,&e);
        if(e.type==ConfigureNotify){W=e.xconfigure.width;H=e.xconfigure.height;needsRedraw=true;}
        else if(e.type==Expose){needsRedraw=true;}
        else if(e.type==ButtonPress){
            if(e.xbutton.button==4){zoom=std::min(1.7,zoom*1.1);needsRedraw=true;}
            else if(e.xbutton.button==5){zoom=std::max(.45,zoom/1.1);needsRedraw=true;}
            else if(e.xbutton.button==1){int h=hitCurrent(e.xbutton.x,e.xbutton.y); if(h>=0){selected=h;needsRedraw=true;} else {dragging=true;dragX=e.xbutton.x;dragY=e.xbutton.y;}}
        } else if(e.type==ButtonRelease){if(e.xbutton.button==1)dragging=false;}
        else if(e.type==MotionNotify && dragging){int dx=e.xmotion.x-dragX,dy=e.xmotion.y-dragY;rotY+=dx*.008;rotX+=dy*.006;dragX=e.xmotion.x;dragY=e.xmotion.y;needsRedraw=true;}
        else if(e.type==KeyPress){ KeySym k=XLookupKeysym(&e.xkey,0);
            if(k==XK_Escape){break;}
            if(k==XK_BackSpace){enterDir(parentPath(currentPath));buildRings();}
            else if(k==XK_Return || k==XK_KP_Enter){if(selected>=0){ if(currentItems[selected].dir){enterDir(currentItems[selected].path);buildRings();} else launch(currentItems[selected].path); }}
            else if(k==XK_Up){if(selected>0)selected--;needsRedraw=true;}
            else if(k==XK_Down){if(selected+1<(int)currentItems.size())selected++;needsRedraw=true;}
            else if(k==XK_Home){enterDir(home?home:"/");buildRings();}
        }
        if(needsRedraw){draw();needsRedraw=false;}
    }
    XFreeGC(dpy,gc);XDestroyWindow(dpy,win);XCloseDisplay(dpy);return 0;
}
